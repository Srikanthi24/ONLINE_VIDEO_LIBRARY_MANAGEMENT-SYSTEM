import "./App.css";
import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./components/Login";
import Signup from "./components/Signup";
import Movies from "./components/Movies";
import AddMovies from "./components/AddMovies";
import EditMovie from "./components/EditMovie";
import PageNotFound from "./components/PageNotFound";
import Navbars from "./components/Navbar";
import Admin from "./components/Admin";

function App() {
  let imagePath =
    "https://images.pexels.com/photos/1097930/pexels-photo-1097930.jpeg";
  return (
    <div
      style={{
        backgroundImage: `url('${imagePath}')`,
        backgroundPosition: "center",
        backgroundSize: "cover",
        backgroundRepeat: "no-repeat",
        width: "100vw",
        height: "100vh",
      }}
      className="App"
    >
      <Navbars />
      <BrowserRouter>
        <Routes>
          <Route exact path="/" element={<Movies />} />
          <Route exact path="/signup" element={<Signup />} />
          <Route exact path="/login" element={<Login />} />
          <Route exact path="/addmovie" element={<AddMovies />} />
          <Route exact path="/editmovie/:id" element={<EditMovie />} />
          <Route exact path="/admin" element={<Admin />} />
          <Route path="*" element={<PageNotFound />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
