import axios from "axios";
import React from "react";
import { Link, Navigate } from "react-router-dom";
import { moviesActions } from "./MoviesActions";
import { url } from "./Url";
import FileBase from "react-file-base64";

const AddMovies = () => {
  const [formDetails, setformDetails] = React.useState(undefined);
  const [pageRefresh, setpageRefresh] = React.useState(false);
  // const [movies, setmovies] = React.useState(undefined);
  // React.useEffect(() => {
  //   moviesActions("getallmovies").then((data) => setmovies(data));
  // }, []);
  React.useEffect(() => {}, [pageRefresh]);
  let user = localStorage.getItem("user");
  if (!user) {
    return <Navigate to="/login" />;
  }
  const logout = () => {
    localStorage.removeItem("user");
    setpageRefresh(true);
  };

  const submitForm = async (e) => {
    console.log(formDetails);
    e.preventDefault();
    const { data } = await axios.post(`${url}/movies/addNewMovie`, formDetails);
    if (data.success) {
      alert("new movie is added..");
      let form = document.getElementById("form");
      form.reset();
    } else {
      alert("Internel server error!");
    }
  };

  return (
    <div style={{ textAlign: "center" }}>
      <div>
        <br />
        <div style={{ marginLeft: "-50px" }}>
          <form action="" id="form" onSubmit={submitForm}>
            <label style={{ marginLeft: "-15px" }}>Video Poster:</label>
            <br />
            <div
              style={{
                border: "1px solid black",
                width: "40%",
                margin: "auto",
              }}
            >
              {" "}
              <FileBase
                type="file"
                multiple={false}
                onDone={({ base64 }) =>
                  setformDetails({ ...formDetails, image: base64 })
                }
              />
            </div>
            <br />
            <label>Video Name: </label>
            <br />
            <input
              style={{ width: "40%" }}
              onChange={(e) =>
                setformDetails({ ...formDetails, name: e.target.value })
              }
              type="text"
              required
            />
            <br />
            <label>Production company: </label>
            <br />
            <input
              style={{ width: "40%" }}
              type="text"
              onChange={(e) =>
                setformDetails({
                  ...formDetails,
                  production_company: e.target.value,
                })
              }
              required
            />
            <br />
            <label htmlFor="select">Languague:</label>
            <br />

            <select
              style={{ margin: 4, padding: 10, width: "40%" }}
              name=""
              id=""
              onChange={(e) =>
                setformDetails({ ...formDetails, language: e.target.value })
              }
            >
              <option defaultChecked value="">
                Select Languague
              </option>
              <option value="English">English</option>
              <option value="Portuguese">Portuguese</option>
              <option value="Russian">Russian</option>
              <option value="Bengali">Bengali</option>
              <option value="Telgu">Telgu</option>
            </select>
            <br />
            <label htmlFor="select">Genere:</label>
            <br />

            <select
              style={{ margin: 4, padding: 10, width: "40%" }}
              name=""
              id=""
              onChange={(e) =>
                setformDetails({ ...formDetails, genre: e.target.value })
              }
            >
              <option defaultChecked value="">
                Select genere
              </option>
              <option value="Science Fiction">Science Fiction</option>
              <option value="Horror">Horror</option>
              <option value="Historical Fiction">Historical Fiction</option>
              <option value="Fantasy">Fantasy</option>
            </select>
            <br />
            <br />
            <input type="submit" value={"save"} />
            <Link to={"/"}>
              <button style={{ marginLeft: 15 }}>Cancel</button>
            </Link>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddMovies;
