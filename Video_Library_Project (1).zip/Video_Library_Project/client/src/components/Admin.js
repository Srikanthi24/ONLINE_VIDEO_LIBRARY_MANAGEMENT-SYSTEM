import axios from "axios";
import React, { useEffect, useState } from "react";
import {
  Button,
  Col,
  Container,
  Form,
  FormControl,
  InputGroup,
  ListGroup,
  Nav,
  Row,
  Tab,
  Table,
} from "react-bootstrap";
import { moviesActions } from "./MoviesActions";
import { url } from "./Url";

const Admin = () => {
  const [users, setusers] = useState();
  const [movies, setmovies] = useState(undefined);

  useEffect(() => {
    getUsersData();
    moviesActions("getallmovies").then((data) => setmovies(data.data));
  }, []);
  //   users data
  const getUsersData = async () => {
    const { data } = await axios.get(`${url}/user/getallUsers`);
    console.log(data.data);
    setusers(data.data);
  };

  return (
    <div>
      <Container>
        <Tab.Container id="left-tabs-example" defaultActiveKey="first">
          <Row style={{ background: "black", opacity: "0.8", height: "500px",borderRadius:20 }}>
            <Col sm={3}>
              <Nav variant="pills" className="flex-column">
                <p
                  style={{
                    padding: 6,
                    background: "lightgrey",
                    fontSize: 10,
                    color: "black",
                  }}
                >
                  Authentication And Authorization
                </p>
                <Nav.Item>
                  <Nav.Link eventKey="first">Groups</Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link eventKey="second">Users</Nav.Link>
                </Nav.Item>
              </Nav>
              <Nav variant="pills" className="flex-column">
                <p
                  style={{ padding: 6, background: "lightgrey", fontSize: 12 }}
                >
                  Books
                </p>
                <Nav.Item>
                  <Nav.Link eventKey="books">1.Books</Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link eventKey="genre">2.Genre</Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link eventKey="language">3.Languague</Nav.Link>
                </Nav.Item>
              </Nav>
            </Col>
            <Col sm={9}>
              {/* first portion */}
              <Tab.Content>
                <Tab.Pane eventKey="first">
                  <h5 style={{color:"white"}}>Change Groups</h5>
                  <div class="container h-100">
                    <div class="row h-100 justify-content-center align-items-center"></div>
                    <InputGroup className="col-6">
                      <FormControl
                        placeholder="Search"
                        aria-label="Search"
                        aria-describedby="basic-addon2"
                      />
                      <Button variant="outline-secondary" id="button-addon2">
                        Search
                      </Button>
                    </InputGroup>
                  </div>
                </Tab.Pane>
                <Tab.Pane eventKey="second">
                  {/* first portion data */}
                  <h5 style={{color:"white"}}>Select User to change</h5>
                  <Table striped bordered hover style={{color:"white"}}>
                    <thead style={{color:"white"}}>
                      <tr style={{color:"white"}}>
                        <th>#</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>email</th>
                      </tr>
                    </thead>
                    <tbody>
                      {users &&
                        users.map((val, index) => (
                          <tr>
                            <td style={{color:"white"}}>{index + 1}</td>
                            <td style={{color:"white"}}>{val.firstName}</td>
                            <td style={{color:"white"}}>{val.lastName}</td>
                            <td style={{color:"white"}}>{val.email}</td>
                          </tr>
                        ))}
                    </tbody>
                  </Table>
                </Tab.Pane>
              </Tab.Content>

              {/* second portion */}
              <Tab.Content>
                <Tab.Pane eventKey="books" style={{color:"white"}}>
                  <h5>Select Book to Change</h5>
                  <Table striped bordered hover style={{color:"white"}}>
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Image</th>
                        <th>Author</th>
                        <th>Genre</th>
                      </tr>
                    </thead>
                    <tbody>
                      {movies !== undefined &&
                        movies.map((val, index) => (
                          <tr>
                            <td style={{color:"white"}}>{index + 1}</td>
                            <td style={{color:"white"}}>{val.id}</td>
                            <td style={{color:"white"}}>{val.name}</td>
                            <td >
                              <img
                                src={val.image}
                                style={{
                                  width: 30,
                                  height: 30,
                                  borderRadius: 30,
                                }}
                              />
                            </td>
                            <td style={{color:"white"}}>{val.production_company}</td>
                            <td style={{color:"white"}}>{val.genre}</td>
                          </tr>
                        ))}
                    </tbody>
                  </Table>
                </Tab.Pane>
                <Tab.Pane eventKey="genre">
                  <h5 style={{color:"white"}}>Select genre to Change</h5>
                  <ListGroup style={{ width: "200px" }}>
                    <ListGroup.Item style={{ background: "lightgrey" }}>
                      Genre
                    </ListGroup.Item>
                    <ListGroup.Item style={{ fontSize: "10px" }}>
                      <Form>
                        <Form.Check
                          type="checkbox"
                          id={`Science Fiction`}
                          label={`Science Fiction`}
                          value={"Science Fiction"}
                          //   onClick={() =>
                          //     findMovie("Science Fiction", "checked1")
                          //   }
                          //   checked={checked}
                        />
                      </Form>
                    </ListGroup.Item>

                    <ListGroup.Item style={{ fontSize: "10px" }}>
                      <Form>
                        <Form.Check
                          type="checkbox"
                          id={`Horror`}
                          label={`Horror`}
                          value={"Horror"}
                          //   onClick={() => findMovie("Horror", "checked2")}
                          //   checked={checked2}
                        />
                      </Form>
                    </ListGroup.Item>
                    <ListGroup.Item style={{ fontSize: "10px" }}>
                      <Form>
                        <Form.Check
                          type="checkbox"
                          id={`Historical Fiction`}
                          label={`Historical Fiction`}
                          value={"Historical Fiction"}
                          //   onClick={() =>
                          //     findMovie("Historical Fiction", "checked3")
                          //   }
                          //   checked={checked3}
                        />
                      </Form>
                    </ListGroup.Item>
                    <ListGroup.Item style={{ fontSize: "10px" }}>
                      <Form>
                        <Form.Check
                          type="checkbox"
                          id={`Fantasy`}
                          label={`Fantasy`}
                          value={"Fantasy"}
                          //   onClick={() => findMovie("Fantasy", "checked4")}
                          //   checked={checked4}
                        />
                      </Form>
                    </ListGroup.Item>
                  </ListGroup>
                </Tab.Pane>
                <Tab.Pane eventKey="language">
                  <h5 style={{color:"white"}}>Select language to change</h5>
                  <ListGroup style={{ width: "200px" }}>
                    <ListGroup.Item style={{ background: "lightgrey" }}>
                      Select Languague
                    </ListGroup.Item>
                    <ListGroup.Item style={{ fontSize: "10px" }}>
                      <Form>
                        <Form.Check
                          type="checkbox"
                          id={`English`}
                          label={`English`}
                          value={"English"}
                          //   onClick={() => findMovie("English", "checked5")}
                          //   checked={checked5}
                        />
                      </Form>
                    </ListGroup.Item>

                    <ListGroup.Item style={{ fontSize: "10px" }}>
                      <Form>
                        <Form.Check
                          type="checkbox"
                          id={`Portuguese`}
                          label={`Portuguese`}
                          value={"Portuguese"}
                          //   onClick={() => findMovie("Portuguese", "checked6")}
                          //   checked={checked6}
                        />
                      </Form>
                    </ListGroup.Item>
                    <ListGroup.Item style={{ fontSize: "10px" }}>
                      <Form>
                        <Form.Check
                          type="checkbox"
                          id={`Russian`}
                          label={`Russian`}
                          value={"Russian"}
                          //   onClick={() => findMovie("Russian", "checked7")}
                          //   checked={checked7}
                        />
                      </Form>
                    </ListGroup.Item>
                    <ListGroup.Item style={{ fontSize: "10px" }}>
                      <Form>
                        <Form.Check
                          type="checkbox"
                          id={`Telgu`}
                          label={`Telgu`}
                          value={"Telgu"}
                          //   onClick={() => findMovie("Telgu", "checked8")}
                          //   checked={checked8}
                        />
                      </Form>
                    </ListGroup.Item>
                    <ListGroup.Item style={{ fontSize: "10px" }}>
                      <Form>
                        <Form.Check
                          type="checkbox"
                          id={`Bengali`}
                          label={`Bengali`}
                          value={"Bengali"}
                          //   onClick={() => findMovie("Bengali", "checked9")}
                          //   checked={checked9}
                        />
                      </Form>
                    </ListGroup.Item>
                  </ListGroup>
                </Tab.Pane>
              </Tab.Content>
            </Col>
          </Row>
        </Tab.Container>
      </Container>
    </div>
  );
};

export default Admin;
