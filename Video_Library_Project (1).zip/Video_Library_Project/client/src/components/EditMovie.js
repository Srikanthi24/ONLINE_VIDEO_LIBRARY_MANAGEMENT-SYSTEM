import axios from "axios";
import React from "react";
import { Link, Navigate, useParams } from "react-router-dom";
import { moviesActions } from "./MoviesActions";
import { url } from "./Url";
import FileBase from "react-file-base64";

const EditMovie = () => {
  const [formDetails, setformDetails] = React.useState(undefined);
  const [pageRefresh, setpageRefresh] = React.useState(false);
  React.useEffect(() => {}, [pageRefresh]);
  const [movies, setmovies] = React.useState(undefined);
  const { id } = useParams();
  React.useEffect(() => {
    moviesActions("getallmovies").then((data) =>
      setmovies(...data.data.filter((data) => data.id === parseInt(id)))
    );
  }, []);
  let user = localStorage.getItem("user");

  if (!user) {
    return <Navigate to="/login" />;
  }
  const logout = () => {
    localStorage.removeItem("user");
    setpageRefresh(true);
  };

  const submitForm = async (e) => {
    e.preventDefault();
    const updated = await axios.patch(
      `${url}/movies/update/${movies && movies.id}`,
      formDetails
    );
    let form = document.getElementById("form");
    if (updated.data.success) {
      alert("Data updated successfully");
      // form.reset();
    } else {
      alert("Internel server error!");
    }
  };

  return (
    <div style={{ textAlign: "center" }}>
      <h1>Video-library site</h1>

      <div>
        <h3>Edit Move-{movies && movies.name}</h3>
        <br />
        <div style={{ marginLeft: "-50px" }}>
          <form action="" onSubmit={submitForm}>
            <label>Name: </label>
            <br />
            <input
              style={{ width: "30%" }}
              defaultValue={movies && movies.name}
              onChange={(e) =>
                setformDetails({ ...formDetails, name: e.target.value })
              }
              type="text"
              required
            />
            <br />
            <label style={{ marginLeft: "-2px" }}>Genere:</label>
            <br />
            <input
              style={{ width: "30%" }}
              defaultValue={movies && movies.genre}
              type="text"
              onChange={(e) =>
                setformDetails({ ...formDetails, genre: e.target.value })
              }
              required
            />
            <br />
            <label style={{ marginLeft: "-15px" }}>VideoPoster:</label>
            <br />

            <div
              style={{
                width: "30%",
                margin: "auto",
                border: "1px solid black",
              }}
            >
              <FileBase
                type="file"
                multiple={false}
                onDone={({ base64 }) =>
                  setformDetails({ ...formDetails, image: base64 })
                }
              />
            </div>
            <br />
            <label style={{ marginLeft: "-25px" }}>production_company: </label>
            <br />
            <input
              style={{ width: "30%" }}
              defaultValue={movies && movies.production_company}
              type="text"
              onChange={(e) =>
                setformDetails({
                  ...formDetails,
                  production_company: e.target.value,
                })
              }
              required
            />
            <br />
            <input type="submit" value={"Update"} />
            <Link to={"/"}>
              <button style={{ marginLeft: 15 }}>Cancel</button>
            </Link>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EditMovie;
