import React from "react";
import axios from "axios";
import { url } from "./Url";
import { Navigate, useNavigate } from "react-router-dom";
import { Button } from "react-bootstrap";

const Login = () => {
  const [formDetails, setformDetails] = React.useState(undefined);
  let user = localStorage.getItem("user");
  const navigate = useNavigate();
  if (user) {
    return <Navigate to="/" />;
  }

  const submitForm = async (e) => {
    e.preventDefault();
    const { data } = await axios.post(`${url}/user/login`, formDetails);
    if (data.success) {
      if (data.email !== undefined) {
        localStorage.setItem("user", data.email);
      }
      navigate("/");
      window.location.reload();
    } else {
      alert(data.message);
    }
  };
  return (
    <div
      style={{
        padding: "20px",
        background: "black",
        opacity: "0.8",
        height: "500px",
        color:"white"
      }}
    >
      <h2>Video-libray Site</h2>
      <h4>Log in Page</h4>
      <form action="" onSubmit={submitForm}>
        <label>Email: </label><br />
        <input
          onChange={(e) =>
            setformDetails({ ...formDetails, email: e.target.value })
          }
          type="email"
          required
        />
        <br />
        <label>Password: </label><br />
        <input
          type="password"
          onChange={(e) =>
            setformDetails({ ...formDetails, password: e.target.value })
          }
          required
        />
        <br />
        <Button size="sm" type="submit">
          Submit
        </Button>
        <br />
        <p>
          Not Already have an account?<br />
          <Button
            variant="outline-primary"
            size="sm"
            onClick={() => navigate("/signup")}
          >
            Singnup
          </Button>
        </p>
      </form>
    </div>
  );
};

export default Login;
