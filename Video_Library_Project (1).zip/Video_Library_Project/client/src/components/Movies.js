import axios from "axios";
import React from "react";
import { Link, Navigate } from "react-router-dom";
import { moviesActions } from "./MoviesActions";
import { url } from "./Url";
import { Form, ListGroup } from "react-bootstrap";

const Movies = () => {
  const [find, setfind] = React.useState(undefined);
  const [hidelist, sethidelist] = React.useState(undefined);
  const [formValues, setformValues] = React.useState(undefined);
  const [pageRefresh, setpageRefresh] = React.useState(false);
  const [pageRefresh2, setpageRefresh2] = React.useState(false);
  React.useEffect(() => {}, [pageRefresh]);
  const [movies, setmovies] = React.useState(undefined);
  const [checked, setChecked] = React.useState(null);
  const [checked2, setChecked2] = React.useState(null);
  const [checked3, setChecked3] = React.useState(null);
  const [checked4, setChecked4] = React.useState(null);
  // languages checks
  const [checked5, setChecked5] = React.useState(null);
  const [checked6, setChecked6] = React.useState(null);
  const [checked7, setChecked7] = React.useState(null);
  const [checked8, setChecked8] = React.useState(null);
  const [checked9, setChecked9] = React.useState(null);

  React.useEffect(() => {
    moviesActions("getallmovies").then((data) => setmovies(data.data));
  }, []);
  React.useEffect(() => {
    moviesActions("getallmovies").then();
  }, []);
  let user = localStorage.getItem("user");
  if (!user) {
    return <Navigate to="/login" />;
  }

  const deleteMovie = (id) => {
    moviesActions("deleteMovie", id);
    setpageRefresh2(!pageRefresh2);
    alert("Movie deleted sucessfully!");
    window.location.reload();
  };

  // movie search
  const findMovie = async (value, name) => {
    let myvar;
    if (name === "checked1") {
      setChecked(!checked);
      myvar = checked;
    } else if (name === "checked2") {
      setChecked2(!checked2);
      myvar = checked2;
    } else if (name === "checked3") {
      setChecked3(!checked3);
      myvar = checked3;
    } else if (name === "checked4") {
      setChecked4(!checked4);
      myvar = checked4;
    }
    // languages
    else if (name === "checked5") {
      setChecked5(!checked5);
      myvar = checked5;
    } else if (name === "checked6") {
      setChecked6(!checked6);
      myvar = checked6;
    } else if (name === "checked7") {
      setChecked7(!checked7);
      myvar = checked7;
    } else if (name === "checked8") {
      setChecked8(!checked8);
      myvar = checked8;
    } else if (name === "checked9") {
      setChecked9(!checked9);
      myvar = checked9;
    }

    if (!myvar) {
      const { data } = await axios.get(`${url}/movies/findmovie/${value}`);
      if (data.success) {
        console.log(data.data);
        if (data.data) {
          sethidelist(true);
        }
        setfind(data.data);
        if (!data.data.length) {
          // alert("At least first letter must be matched!");
        }
      }
    } else if (myvar) {
      window.location.reload();
    }
  };

  const search = async (e) => {
    e.preventDefault();
    const { data } = await axios.post(
      `${url}/movies/searchmovie/${formValues.name}`
    );
    if (data.success) {
      if (data.data) {
        sethidelist(true);
      }
      setfind(data.data);
      if (!data.data.length) {
        alert("No results, at leat first letter must be matched!");
      }
    }
  };
  //logout
  // const logout = () => {
  //   localStorage.removeItem("user");
  //   setpageRefresh(true);
  // };
  return (
    <div
      style={{
        display: "flex",
        padding: "20px",
        background: "black",
        opacity: "0.8",
        color: "white",
      }}
    >
      {/* header */}
      <div>
        <ListGroup style={{ width: "200px" }}>
          <h3 style={{ textAlign: "left" }}>Filters</h3>
          <ListGroup.Item style={{ background: "lightgrey" }}>
            Genre
          </ListGroup.Item>
          <ListGroup.Item style={{ fontSize: "10px" }}>
            <Form>
              <Form.Check
                type="checkbox"
                id={`Science Fiction`}
                label={`Science Fiction`}
                value={"Science Fiction"}
                onClick={() => findMovie("Science Fiction", "checked1")}
                checked={checked}
              />
            </Form>
          </ListGroup.Item>

          <ListGroup.Item style={{ fontSize: "10px" }}>
            <Form>
              <Form.Check
                type="checkbox"
                id={`Horror`}
                label={`Horror`}
                value={"Horror"}
                onClick={() => findMovie("Horror", "checked2")}
                checked={checked2}
              />
            </Form>
          </ListGroup.Item>
          <ListGroup.Item style={{ fontSize: "10px" }}>
            <Form>
              <Form.Check
                type="checkbox"
                id={`Historical Fiction`}
                label={`Historical Fiction`}
                value={"Historical Fiction"}
                onClick={() => findMovie("Historical Fiction", "checked3")}
                checked={checked3}
              />
            </Form>
          </ListGroup.Item>
          <ListGroup.Item style={{ fontSize: "10px" }}>
            <Form>
              <Form.Check
                type="checkbox"
                id={`Fantasy`}
                label={`Fantasy`}
                value={"Fantasy"}
                onClick={() => findMovie("Fantasy", "checked4")}
                checked={checked4}
              />
            </Form>
          </ListGroup.Item>
        </ListGroup>
        <br />
        {/* Select Languague */}
        <ListGroup style={{ width: "200px" }}>
          <ListGroup.Item style={{ background: "lightgrey" }}>
            Select Languague
          </ListGroup.Item>
          <ListGroup.Item style={{ fontSize: "10px" }}>
            <Form>
              <Form.Check
                type="checkbox"
                id={`English`}
                label={`English`}
                value={"English"}
                onClick={() => findMovie("English", "checked5")}
                checked={checked5}
              />
            </Form>
          </ListGroup.Item>

          <ListGroup.Item style={{ fontSize: "10px" }}>
            <Form>
              <Form.Check
                type="checkbox"
                id={`Portuguese`}
                label={`Portuguese`}
                value={"Portuguese"}
                onClick={() => findMovie("Portuguese", "checked6")}
                checked={checked6}
              />
            </Form>
          </ListGroup.Item>
          <ListGroup.Item style={{ fontSize: "10px" }}>
            <Form>
              <Form.Check
                type="checkbox"
                id={`Russian`}
                label={`Russian`}
                value={"Russian"}
                onClick={() => findMovie("Russian", "checked7")}
                checked={checked7}
              />
            </Form>
          </ListGroup.Item>
          <ListGroup.Item style={{ fontSize: "10px" }}>
            <Form>
              <Form.Check
                type="checkbox"
                id={`Telgu`}
                label={`Telgu`}
                value={"Telgu"}
                onClick={() => findMovie("Telgu", "checked8")}
                checked={checked8}
              />
            </Form>
          </ListGroup.Item>
          <ListGroup.Item style={{ fontSize: "10px" }}>
            <Form>
              <Form.Check
                type="checkbox"
                id={`Bengali`}
                label={`Bengali`}
                value={"Bengali"}
                onClick={() => findMovie("Bengali", "checked9")}
                checked={checked9}
              />
            </Form>
          </ListGroup.Item>
        </ListGroup>
      </div>
      {/* <div
        style={{
          padding: 10,
          display: "flex",
          justifyContent: "space-between",
          width: 350,
          margin: "auto",
          display: "inline",
        }}
      >
        <button onClick={() => logout()}>Logout</button>
      </div> */}
      {/* movies list */}
      {/* <div> */}
      <div>
        <h2>Video List</h2>
        Search Engine
        <form action="" onSubmit={search}>
          <input
            placeholder="Search a Movie..."
            type="text"
            onChange={(e) =>
              setformValues({ ...formValues, name: e.target.value })
            }
            required
          />
          <input type="submit" value={"Search"} />
        </form>
      </div>

      {/* show movies */}
      {!hidelist && (
        <div
          style={{
            display: "flex",
            justifyContent: "space-around",
            width: "100%",
            flexWrap: "wrap",
          }}
        >
          {movies !== undefined &&
            movies.map((val, index) => (
              <div
                key={index}
                style={{ border: "1px solid black", padding: 10, height: 390 }}
              >
                <div
                  style={{ cursor: "pointer" }}
                  onClick={() =>
                    window.location.replace("https://www.amazon.com")
                  }
                >
                  {" "}
                  <img width={200} height={300} src={val.image} alt="" />
                </div>
                <div>
                  <p style={{ fontWeight: "bold" }}>{val.name}</p>
                  <Link to={`/editmovie/${val.id}`}>
                    <button>Edit</button>
                  </Link>
                  <button onClick={() => deleteMovie(val.id)}>Delete</button>
                </div>
              </div>
            ))}
        </div>
      )}

      {/* search results */}
      {/* <div>
        {find !== undefined && <h2>Search results:</h2>}
        {find !== undefined &&
          find.map((val, index) => (
            <div>
              <div
                key={index}
                style={{
                  border: "1px solid black",
                  width: "300px",
                  margin: "auto",
                }}
              >
                <p style={{ fontWeight: "bold" }}>{val.name}</p>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    width: "100px",
                    margin: "auto",
                  }}
                >
                  <img width={400} src={val.image} alt="" />
                </div>
                <Link to={`/editmovie/${val.id}`}>
                  <button>Edit</button>
                </Link>
                <button onClick={() => deleteMovie(val._id)}>Delete</button>
              </div>
            </div>
          ))}
      </div> */}
      {/* </div> */}

      <div>
        {/* {find !== undefined && <h2>Search results:</h2>} */}
        {find !== undefined &&
          find.map((val, index) => (
            <div key={index}>
              <div>
                {" "}
                <img
                  width={200}
                  height={300}
                  style={{ border: "1px solid black", padding: 10 }}
                  src={val.image}
                  alt=""
                />
              </div>
              <div>
                <p style={{ fontWeight: "bold" }}>{val.name}</p>
                <span>{val.genre}</span>
                <Link to={`/editmovie/${val.id}`}>
                  <button>Edit</button>
                </Link>
                <button onClick={() => deleteMovie(val.id)}>Delete</button>
              </div>
            </div>
          ))}
      </div>
    </div>
  );
};

export default Movies;
