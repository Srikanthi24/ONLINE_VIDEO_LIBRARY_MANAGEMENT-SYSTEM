import axios from "axios";
import { url } from "./Url";
const moviesActions = async (type, id) => {
  try {
    switch (type) {
      case "getallmovies":
        const { data } = await axios.get(`${url}/movies/getallmovies`);
        if (data.success) {
          return data;
        }
        break;
      case "deleteMovie":
        const deleted = await axios.delete(`${url}/movies/delete/${id}`);
        if (deleted.data.success) {
          return "deleted";
        }
        break;
      default:
        break;
    }
  } catch (error) {
    console.log("error", error);
  }
};

export { moviesActions };
