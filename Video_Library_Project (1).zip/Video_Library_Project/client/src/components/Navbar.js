import React from "react";
import { Container, Nav, Navbar } from "react-bootstrap";
import {
  faHome,
  faVideo,
  faShop,
  faReceipt,
  faRedoAlt,
  faArrowUpWideShort,
  faPerson,
  faSignIn,
  faUserPlus,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

const Navbars = () => {
  let user = localStorage.getItem("user");
  const logout = () => {
    localStorage.removeItem("user");
    window.location.reload();
  };
  return (
    <div>
      <Navbar bg="light" expand="lg">
        <Container>
          <Navbar.Brand href="/">Video Library</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link href="/">
                {" "}
                <FontAwesomeIcon icon={faHome} />
                <p style={{ fontSize: 13 }}> Home</p>
              </Nav.Link>
              <Nav.Link href="/addmovie">
                {" "}
                <FontAwesomeIcon icon={faVideo} />{" "}
                <p style={{ fontSize: 13 }}>Add Video</p>
              </Nav.Link>
              <Nav.Link href="/">
                <FontAwesomeIcon icon={faShop} />
                <p style={{ fontSize: 13 }}>Customer</p>
              </Nav.Link>
              <Nav.Link href="/">
                <FontAwesomeIcon icon={faReceipt} />
                <p style={{ fontSize: 13 }}>Rent</p>
              </Nav.Link>
              <Nav.Link href="/">
                <FontAwesomeIcon icon={faRedoAlt} />
                <p style={{ fontSize: 13 }}>Return</p>
              </Nav.Link>
              <Nav.Link href="/">
                <FontAwesomeIcon icon={faArrowUpWideShort} />
                <p style={{ fontSize: 13 }}>Rental_Report</p>
              </Nav.Link>

              {!user ? (
                <Nav.Link href="/login">
                  <p style={{ fontSize: 13 }}>
                    <FontAwesomeIcon icon={faSignIn} />
                    Login
                  </p>
                </Nav.Link>
              ) : (
                <Nav.Link onClick={() => logout()}>
                  <FontAwesomeIcon icon={faSignIn} />
                  <p style={{ fontSize: 13 }}>Logout</p>
                </Nav.Link>
              )}
              <Nav.Link href="/signup">
                <FontAwesomeIcon icon={faUserPlus} />
                <p style={{ fontSize: 13 }}>Signup</p>
              </Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </div>
  );
};

export default Navbars;
