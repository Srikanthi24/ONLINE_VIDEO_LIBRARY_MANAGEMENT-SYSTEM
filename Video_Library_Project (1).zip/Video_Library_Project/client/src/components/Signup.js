import React from "react";
import axios from "axios";
import { url } from "./Url";
import { Navigate, useNavigate } from "react-router-dom";
import { Button } from "react-bootstrap";

const Login = () => {
  const [formDetails, setformDetails] = React.useState(undefined);
  let user = localStorage.getItem("user");
  const navigate = useNavigate();
  // if (user) {
  //   return <Navigate to="/" />;
  // }

  const submitForm = async (e) => {
    e.preventDefault();
    const { data } = await axios.post(`${url}/user/signup`, formDetails);

    if (data.success) {
      alert(data.message);
      localStorage.setItem("user", data.email);
      navigate("/");
      window.location.reload();
    } else if (data.success === false) {
      alert("Internel server error!");
    }
  };
  return (
    <div style={{ padding: "20px",
      padding: "20px",
      background: "black",
      opacity: "0.8",
      height: "500px",
      color:"white"
     }}>
      <h2>Video-libray Site</h2>
      <h4>Signup Page</h4>
      <form action="" onSubmit={submitForm}>
        <label>First Name: </label><br />
        <input
          onChange={(e) =>
            setformDetails({ ...formDetails, firstName: e.target.value })
          }
          type="text"
          required
        />
        <br />
        <label>Last Name: </label><br />
        <input
          onChange={(e) =>
            setformDetails({ ...formDetails, lastName: e.target.value })
          }
          type="text"
          required
        />{" "}
        <br />
        <label> Email(New): </label><br />
        <input
          onChange={(e) =>
            setformDetails({ ...formDetails, email: e.target.value })
          }
          type="email"
          required
        />
        <br />
        <label>Password: </label><br />
        <input
          type="password"
          onChange={(e) =>
            setformDetails({ ...formDetails, password: e.target.value })
          }
          required
        />
        <br />
        <Button size="sm" type="submit">
          Signup
        </Button>
      </form>
    </div>
  );
};

export default Login;
