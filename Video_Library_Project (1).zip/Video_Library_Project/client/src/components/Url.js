const url = "http://localhost:1000/api/v1";
export { url };
