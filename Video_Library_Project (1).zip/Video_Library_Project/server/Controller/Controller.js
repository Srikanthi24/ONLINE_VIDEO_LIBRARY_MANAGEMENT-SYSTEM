const { myconn } = require("../DB_Connect");
// 1.add movies
exports.addMovies = async (req, res) => {
  try {
    const { name, genre, image, production_company, language } = req.body;
    myconn.query(
      "CREATE TABLE IF NOT EXISTS videos(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(255),genre VARCHAR(255),image VARCHAR(65535), production_company VARCHAR(255),language VARCHAR(255))"
    );
    myconn.query(
      `INSERT INTO videos (name,genre,image,production_company,language) VALUES ("${name}","${genre}","${image}","${production_company}","${language}")`,
      (err, results) => {
        if (!err) {
          res.json({
            success: true,
            message: "Movie created successfully",
          });
        } else if (err) {
          res.json({ success: false });
        }
      }
    );
  } catch (error) {
    console.log("error in add movies", error);
    res.status(404).json({ success: false, message: "Internel server error" });
  }
};

// 2.get all movies
exports.getAllMovies = async (req, res) => {
  try {
    myconn.query(`SELECT * FROM videos`, (err, results) => {
      if (!err) {
        res.json({
          success: true,
          data: results,
        });
      } else if (err) {
        res.json({ success: false });
      }
    });
    // await res
    //   .status(200)
    //   .json({ success: true, data: movies, findedMovies: findedMovies });
  } catch (error) {
    console.log("error in get all movies", error);
    res.status(404).json({ success: false, message: "Internel server error" });
  }
};
// find a movie
exports.findmovie = async (req, res) => {
  const { value } = req.params;
  try {
    myconn.query(
      `SELECT * FROM videos WHERE genre='${value}' OR language='${value}'`,
      (err, results) => {
        if (!err) {
          res.json({
            success: true,
            message: "data found",
            data: results,
          });
        } else if (err) {
          res.json({ success: false });
        }
      }
    );
  } catch (error) {
    console.log("error in find movies", error);
    res.status(404).json({ success: false, message: "Internel server error" });
  }
};

// searchmovie
exports.searchmovie = async (req, res) => {
  const { data } = req.params;
  try {
    myconn.query(
      `SELECT * FROM videos WHERE name LIKE '${data}%'`,
      (err, results) => {
        console.log(results);
        if (!err) {
          res.json({
            success: true,
            message: "data found",
            data: results,
          });
        } else if (err) {
          res.json({ success: false });
        }
      }
    );
  } catch (error) {
    console.log("error in find movies", error);
    res.status(404).json({ success: false, message: "Internel server error" });
  }
};

//delete a single movie
exports.deleteSingleMovie = async (req, res) => {
  const { id } = req.params;
  try {
    myconn.query(`DELETE FROM videos WHERE id='${id}'`, (err, results) => {
      if (!err) {
        res.json({
          success: true,
          message: "Video deleted succesfully",
        });
      } else if (err) {
        res.json({ success: false });
      }
    });
  } catch (error) {
    console.log("error in delete movies", error);
    res.status(404).json({ success: false, message: "Internel server error" });
  }
};

//update a movie
exports.updateSingleMovie = async (req, res) => {
  let qeury;
  let data;
  const { id } = req.params;
  const { name, genre, image, production_company } = req.body;
  if (name && genre && image && production_company) {
    qeury = `UPDATE videos SET name=?,genre=?,image=?,production_company=? WHERE id='${id}'`;
    data = [name, genre, image, production_company];
  } else if (name && genre && image) {
    qeury = `UPDATE videos SET name=?,genre=?,image=? WHERE id='${id}'`;
    data = [name, genre, image];
  } else if (name && genre) {
    qeury = `UPDATE videos SET name=?,genre=? WHERE id='${id}'`;
    data = [name, genre];
  } else if (name) {
    qeury = `UPDATE videos SET name=? WHERE id='${id}'`;
    data = [name];
  } else if (genre) {
    qeury = `UPDATE videos SET genre=? WHERE id='${id}'`;
    data = [genre];
  } else if (image) {
    qeury = `UPDATE videos SET image=? WHERE id='${id}'`;
    data = [image];
  } else if (production_company) {
    qeury = `UPDATE videos SET production_company=? WHERE id='${id}'`;
    data = [production_company];
  } else {
    res.json({
      success: true,
      message: "Video updated succesfully",
    });
  }

  if (qeury) {
    myconn.query(qeury, data, function (err, result, fields) {
      if (err) {
        console.log(err);
        res.json({ success: false, message: "Internal sever error" });
      } else {
        res.json({
          success: true,
          message: "Video updated succesfully",
        });
      }
    });
  }

  try {
  } catch (error) {
    console.log("error in update movies", error);
    res.status(404).json({ success: false, message: "Internel server error" });
  }
};


//update a movie
exports.updateSingleSubs = async (req, res) => {
  const { id } = req.params;
  try {
    const subsupdate = await MembersModel.findByIdAndUpdate(
      { _id: id },
      req.body
    );
    if (subsupdate) {
      res.status(200).json({ success: true, data: subsupdate });
    }
  } catch (error) {
    console.log("error in update Members/subs", error);
    res.status(404).json({ success: false, message: "Internel server error" });
  }
};
