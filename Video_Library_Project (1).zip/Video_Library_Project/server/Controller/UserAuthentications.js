const { myconn } = require("../DB_Connect");

//Login
exports.Login = async (req, res) => {
  try {
    const { email, password } = req.body;
    myconn.query(
      `SELECT * FROM users WHERE email='${email}'and password='${password}'`,
      function (err, result, fields) {
        if (err) {
          res.json({ success: false, message: "Incorrect email or password! If don't have account please signup" });
        } else if (result.length !== 0) {
          res.json({
            success: true,
            email: email,
            message: "Logged in successfully",
          });
        } else if (result.length === 0) {
          res.json({
            success: true,
            message: "Your account not exists, Please signup!",
          });
        }
      }
    );
  } catch (error) {
    console.log("Error found in login", error);
    res.json({ success: false, message: "Internel server error" });
  }
};

//Signup
exports.Signup = async (req, res) => {
  try {
    const { firstName, lastName, email, password } = req.body;
    myconn.query(
      "CREATE TABLE IF NOT EXISTS users(id INT AUTO_INCREMENT PRIMARY KEY,firstName VARCHAR(255),lastName VARCHAR(255),email  VARCHAR(255), password VARCHAR(255))"
    );
    myconn.query(
      `INSERT INTO users (firstName,lastName,email,password) VALUES ("${firstName}","${lastName}","${email}","${password}")`,
      (err, results) => {
        if (!err) {
          res.json({
            success: true,
            message: "Accounted created successfully",
            email: email,
          });
        } else if (err) {
          res.json({ success: false });
        }
      }
    );
  } catch (error) {
    console.log("Error found in login", error);
  }
};

// get all users
exports.getAllUsers = async (req, res) => {
  try {
    myconn.query(`SELECT * FROM  users`, (err, results) => {
      if (!err) {
        res.json({
          success: true,
          message: "We got users data",
          data: results,
        });
      } else if (err) {
        res.json({ success: false });
      }
    });
  } catch (error) {
    console.log("Error found get all users", error);
  }
};
