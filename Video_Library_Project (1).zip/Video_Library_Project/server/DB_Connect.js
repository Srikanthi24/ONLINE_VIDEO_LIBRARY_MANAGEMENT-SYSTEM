const mysql = require("mysql");
//database connection
let myconn = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
});
myconn.connect((err) => {
  if (err) {
    console.log("DB_connect_ERR Failed");
  } else {
    console.log("DB_connect_Success");
    myconn.query("CREATE DATABASE IF NOT EXISTS video_library", function (err) {
      if (err) {
        console.log("Err_create_DB", err);
      } else {
        myconn.changeUser({ database: "video_library" });
      }
    });
  }
});

module.exports = { myconn };
