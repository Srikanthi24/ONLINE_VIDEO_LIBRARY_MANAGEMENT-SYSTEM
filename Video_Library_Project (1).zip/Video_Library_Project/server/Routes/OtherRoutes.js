const express = require("express");
const router = express.Router();
const {
  addMovies,
  getAllMovies,
  deleteSingleMovie,
  updateSingleMovie,
  findmovie,
  searchmovie,
} = require("../Controller/Controller");
router.route("/addNewMovie").post(addMovies);
router.route("/getallmovies").get(getAllMovies);
router.route("/findmovie/:value").get(findmovie);
router.route("/searchmovie/:data").post(searchmovie);
router.route("/delete/:id").delete(deleteSingleMovie);
router.route("/update/:id").patch(updateSingleMovie);

module.exports = router;
