const express = require("express");
const router = express.Router();
const { Login,Signup,getAllUsers } = require("../Controller/UserAuthentications");
router.route("/login").post(Login);
router.route("/signup").post(Signup);
router.route("/getallUsers").get(getAllUsers);
module.exports = router;
