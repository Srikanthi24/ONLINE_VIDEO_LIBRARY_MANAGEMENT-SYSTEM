const express = require("express");
const cors = require("cors");
const userRoutes = require("../Routes/UserRoutes");
const OtherRoutes = require("../Routes/OtherRoutes");
const app = express();
app.use(express.json({ limit: "50mb" })); //requesting bodies from fontend
app.use(cors());
app.get("/", (req, res) => {
  res.send("welcome to backend movies");
});

app.use("/api/v1/user", userRoutes);
app.use("/api/v1/movies", OtherRoutes);

//except the above routes,let's caught it
// app.all("*", (req, res) => {
//   throw new Error("This route deos not exists in the server");
// });

var Port = process.env.PORT || 1000;
app.listen(Port, () => {
  console.log(`server is up at port ${Port}`);
});
